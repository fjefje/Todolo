/*
Create user:
METHOD: POST
ENDPOINT: api/user
BODY (json): {"name":"Jonas Magnussen", "email":"jonasmagnussen@gmail.com", "password":"12345678"}
RESPONS (json): { "id":"123456", "name":"Jonas Magnussen", "email":"jonasmagnussen@gmail.com", "password":"12345678"}
 */